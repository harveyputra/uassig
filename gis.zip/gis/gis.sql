-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 13 Jun 2021 pada 13.36
-- Versi server: 10.3.16-MariaDB
-- Versi PHP: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gis`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_galeri`
--

CREATE TABLE `tb_galeri` (
  `id_galeri` int(11) NOT NULL,
  `id_tempat` int(11) NOT NULL,
  `nama_galeri` varchar(255) NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `ket_galeri` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_galeri`
--

INSERT INTO `tb_galeri` (`id_galeri`, `id_tempat`, `nama_galeri`, `gambar`, `ket_galeri`) VALUES
(34, 14, 'Uluwatu 2', '6237uluwatu-2.jpg', ''),
(37, 15, 'View Hotel', '2675bloo-3.jpg', ''),
(38, 15, 'Lounge Room', '2527bloo-2.jpg', ''),
(39, 15, 'Pool View', '2116bloo.jpg', ''),
(40, 16, 'Hotel View', '3876natya.jpg', ''),
(41, 16, 'Bedroom', '4545natya-2.jpg', ''),
(42, 16, 'Lobby', '3295natya-3.jpg', ''),
(43, 17, 'Bedroom', '2773atanaya.jpg', ''),
(44, 17, 'Pool View', '3288atanaya-2.jpg', ''),
(45, 17, 'Hotel View', '17542316atanaya-3.jpg', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_options`
--

CREATE TABLE `tb_options` (
  `option_name` varchar(16) NOT NULL,
  `option_value` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_options`
--

INSERT INTO `tb_options` (`option_name`, `option_value`) VALUES
('default_lat', '-8.251889'),
('default_lng', '115.076818'),
('default_zoom', '10');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_tempat`
--

CREATE TABLE `tb_tempat` (
  `id_tempat` int(11) NOT NULL,
  `nama_tempat` varchar(255) DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `lat` double DEFAULT NULL,
  `lng` double DEFAULT NULL,
  `lokasi` varchar(255) DEFAULT NULL,
  `keterangan` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_tempat`
--

INSERT INTO `tb_tempat` (`id_tempat`, `nama_tempat`, `gambar`, `lat`, `lng`, `lokasi`, `keterangan`) VALUES
(15, 'Bloo Bali Hotel', '3327bloo.jpg', -8.707466416113952, 115.17867001033001, 'Jl. Dewi Sri No.11 A, Kuta, Kabupaten Badung, Bali 80361', '<p>Berlokasi strategis di Jalan Dewi Sri, Legian, Bloo Bali Hotel terletak dekat dengan Bandara Ngurah Rai yang hanya berjarak 6,2 km dan menyediakan akses mudah ke berbagai pantai, pusat perbelanjaan dan restoran. Kamu juga dapat berkendara dalam 15 menit untuk menikmati area Seminyak, kawasan yang populer dengan hiburan malam dan berbagai restoran di Bali, atau berjalan-jalan di Pantai Legian untuk berjemur dan berselancar. Hotel ini memiliki kolam renang outdoor, parkir gratis dan akses WiFi gratis di seluruh area properti.<br /><br />Kamar Bloo Bali Hotel yang luas memiliki pemandangan kolam renang atau kota dan dilengkapi dengan AC, TV kabel layar datar dan lemari es mini. Tersedia ketel listrik untuk memudahkan tamu menyeduh kopi atau teh sendiri. Kamar mandi dalam memiliki shower lengkap dengan handuk dan peralatan mandi gratis.<br /><br />Hotel memiliki restoran yang buka sepanjang hari untuk bersantap dan menyajikan hidangan internasional. Jika kamu ingin mencoba pilihan bersantap lainnya, kamu dapat menemukan berbagai restoran yang menyajikan hidangan lokal di sepanjang Jalan Dewi Sri. Kamu juga dapat mengunjungi Anomaly Coffee, berjarak hanya 100 meter, untuk memenuhi asupan kafein harianmu. Restoran favorit warga lokal, Nasi Tempong Indra, dapat dijangkau dalam 8 menit dengan berjalan kaki dari properti.<br /><br />Staf hotel yang mampu menggunakan dwibahasa dapat mengatur penyewaan mobil atau layanan pengantaran bandara yang tersedia dengan biaya tambahan, sementara layanan antar-jemput untuk area sekitar tersedia gratis untuk para tamu.<br /><br />Bloo Bali Hotel berjarak 4,4 km dari tempat yang populer di Instagram, La Plancha, sementara Pusat Oleh-oleh Krisna dapat dicapai dalam 5 menit dengan berkendara.</p>'),
(16, 'Natya Hotel Kuta', '2080natya.jpg', -8.726547510331399, 115.18009654101934, 'Jalan By Pass Ngurah Rai No.#9, Kuta, Kabupaten Badung, Bali 80361', '<p>Terletak di Kuta, Natya Hotel Kuta merupakan tempat yang sempurna untuk menikmati Bali dan sekitarnya. Dengan lokasinya yang hanya 7.2 km dari pusat kota dan 9.4 km dari bandara, properti bintang 3 ini menarik perhatian banyak wisatawan setiap tahunnya. Karena lokasinya yang strategis, properti ini memiliki akses mudah ke destinasi yang wajib dikunjungi di kota ini.<br /><br />Gunakan kesempatan untuk menikmati pelayanan dan fasilitas yang tidak tertandingi di properti yang ada Bali ini. Ada beberapa fasilitas properti ini seperti WiFi gratis di semua kamar, resepsionis 24 jam, check-in/check-out cepat, Wi-fi di tempat umum, parkir valet.<br /><br />Semua akomodasi tamu dilengkapi dengan fasilitas yang telah dirancang dengan baik demi menjaga kenyamanan maksimum. Bagi Anda yang menyukai aktivitas kebugaran atau hanya ingin bersantai setelah beraktivitas sepanjang hari, Anda akan dihibur dengan fasilitas rekreasi kelas atas seperti kolam renang luar ruangan, spa, pijat, kolam renang anak, taman. Natya Hotel Kuta merupakan sebuah destinasi serbaguna sebagai akomodasi berkualitas untuk Anda di Bali.</p>'),
(17, 'Atanaya Kuta Bali', '2316atanaya-3.jpg', -8.700674047778813, 115.18093580708191, 'Jl. Sunset Road No.88A, Kuta, Kabupaten Badung, Bali 80361', '<p>Terletak di pusat Legian, Atanaya by Century Park Jakarta adalah tempat ideal untuk menelusuri Bali. Hanya 2. Km dari pusat kota, lokasi hotel yang strategis ini memastikan para tamu agar dapat secara cepat dan mudah mencapai ke tempat-tempat menarik. Hotel modern ini terletak di sekitar obyek wisata populer kota ini seperti Krisna Sunset Road, Bali Brasco Shopping Centre, Taman Air Spa.<br /><br />Gunakan kesempatan untuk menikmati pelayanan dan fasilitas yang tidak tertandingi di hotel Bali ini. Hotel ini menawarkan sejumlah fasilitas di tempat untuk memuaskan segala jenis tamu.<br /><br />Nikmati fasilitas kamar berkualitas tinggi selama Anda menginap di sini. Beberapa kamar memiliki televisi layar datar, akses internet - WiFi, akses internet WiFi (gratis), kamar bebas asap rokok, AC, yang disediakan untuk membantu Anda mengumpulkan tenaga kembali setelah lelah beraktivitas. Sepanjang hari Anda dapat menikmati suasana menenangkan dari kolam renang luar ruangan, bilyar. Apapun tujuan kunjungan Anda, Atanaya by Century Park Jakarta adalah pilihan istimewa untuk menginap di Bali.</p>');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_user`
--

CREATE TABLE `tb_user` (
  `id_user` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_user`
--

INSERT INTO `tb_user` (`id_user`, `user`, `pass`) VALUES
(1, 'admin', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_galeri`
--
ALTER TABLE `tb_galeri`
  ADD PRIMARY KEY (`id_galeri`);

--
-- Indeks untuk tabel `tb_options`
--
ALTER TABLE `tb_options`
  ADD PRIMARY KEY (`option_name`);

--
-- Indeks untuk tabel `tb_tempat`
--
ALTER TABLE `tb_tempat`
  ADD PRIMARY KEY (`id_tempat`);

--
-- Indeks untuk tabel `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tb_galeri`
--
ALTER TABLE `tb_galeri`
  MODIFY `id_galeri` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT untuk tabel `tb_tempat`
--
ALTER TABLE `tb_tempat`
  MODIFY `id_tempat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
