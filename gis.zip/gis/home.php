<style type="text/css">
	img {
		width: 100%;
	}
</style>
<div class="page-header">
    <h1 align="center">Promo Hotel Murah</h1>
</div>
<div class="row" style="width: 80%; margin: auto;">
	<div class="col-lg-4">
		<div class="card">
		  <img
		    src="assets/images/tempat/bloo.jpg"
		    class="card-img-top"
		    alt="..."
		  />
		  <div class="card-body">
		    <h4 class="card-title">BLoO Hotel</h4>
		    <p class="card-text">
		      Rating : 4.5/5 <br>
		      Harga : <strong>Rp. 130.000/malam</strong> <br/>
		      Bonus Sarapan
		    </p>
		  </div>
		  <div class="card-body" align="center">
		    <a href="#" class="btn btn-info">Lihat Detail</a>
		  </div>
		</div>
	</div>
	<div class="col-lg-4">
		<div class="card">
		  <img
		    src="assets/images/tempat/natya.jpg"
		    class="card-img-top"
		    alt="..."
		  />
		  <div class="card-body">
		    <h4 class="card-title">Natya Hotel Kuta</h4>
		    <p class="card-text">
		      Rating : 4/5 <br>
		      Harga : <strong>Rp. 121.000/malam</strong> <br/>
		      Bonus Sarapan
		    </p>
		  </div>
		  <div class="card-body" align="center">
		    <a href="#" class="btn btn-info">Lihat Detail</a>
		  </div>
		</div>
	</div>
	<div class="col-lg-4">
		<div class="card">
		  <img
		    src="assets/images/tempat/atanaya-3.jpg"
		    class="card-img-top"
		    alt="..."
		  />
		  <div class="card-body">
		    <h4 class="card-title">Atanaya Hotel Kuta</h4>
		    <p class="card-text">
		      Rating : 4.5/5 <br>
		      Harga : <strong>Rp. 145.000/malam</strong> <br/>
		      Bonus Sarapan
		    </p>
		  </div>
		  <div class="card-body" align="center">
		    <a href="#" class="btn btn-info">Lihat Detail</a>
		  </div>
		</div>
	</div>
</div>